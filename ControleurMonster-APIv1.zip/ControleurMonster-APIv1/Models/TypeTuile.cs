﻿namespace ControleurMonster_APIv1.Models
{
    public enum TypeTuile
    {
        HERBE,
        EAU,
        MONTAGNE,
        FORET,
        VILLE,
        ROUTE,
    }
}
