namespace ControleurMonster_APIv1.Models.Dto
{
    public class RegisterResponseDto
    {
        public int UtilisateurId { get; set; }
        public string Message { get; set; } = string.Empty;
    }
}