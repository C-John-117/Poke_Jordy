﻿namespace ControleurMonster_APIv1.Models
{
    public class PositionDto
    {
        public int X { get; set; }
        public int Y { get; set; }

    }
}
