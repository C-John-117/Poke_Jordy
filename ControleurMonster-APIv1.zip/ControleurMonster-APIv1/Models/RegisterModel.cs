﻿namespace ControleurMonster_APIv1.Models
{
    public class RegisterModel
    {
        public string Email { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
        public string Pseudo { get; set; } = string.Empty;
        public string NomHeros { get; set; } = string.Empty;
    }
}
